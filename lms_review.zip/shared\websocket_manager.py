from fastapi import WebSocket
import logging


class ConnectionManager:
    def __init__(self):
        self.active_connections:dict[str,list[WebSocket]]={}

    async def connect(self,websocket:WebSocket,room_id:str):
        await websocket.accept()
        self.active_connections.setdefault(room_id,set()).add(websocket)
        # if room_id not in self.active_connections:
        #     self.active_connections[room_id]=[]

        # self.active_connections[room_id].append(websocket) 

    def disconnect(self,websocket:WebSocket,room_id:str):
        room=self.active_connections.get(room_id)
        try:
            if room:
                room.discard(websocket)
                if not room:
                    del self.active_connections[room_id]
        except Exception as e:
            logging.exception(f"during discnt socket: {str(e)}")            

        # if room_id in self.active_connections:
        #     self.active_connections[room_id].remove(websocket)
        #     if not self.active_connections[room_id]:
        #         del self.active_connections[room_id]


    async def broadcast_to_room(self,room_id:str,message:dict):
        for connection in list(self.active_connections.get(room_id, ())):
            try:
                await connection.send_json(message)
            except Exception as e:
                logging.exception(f"during brdcst to room: {str(e)}")
                self.disconnect(connection,room_id)
        # if room_id in self.active_connections:
        #     for connection in self.active_connections[room_id]:
        #         await connection.send_json(message)



manager=ConnectionManager()