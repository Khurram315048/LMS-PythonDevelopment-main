# from fastapi import Request,HTTPException,status
# from jose import jwt 
# from core.config import SECRET_KEY
# from core.logger import logging
# ALGORITHM="HS256"

# def get_current_user(request:Request)->dict:
#     user_id=request.session.get('user_id')
#     if not user_id:
#         raise HTTPException(status_code=status.HTTP_303_SEE_OTHER,
#                             headers={"location": "/main_view"})

#     return {"user_id":user_id}


# def get_current_student(request:Request)->dict:
#     token=request.cookies.get("access_token")
#     if not token:
#         raise HTTPException(status_code=status.HTTP_303_SEE_OTHER,headers={"location":"/student_login"})

#     try:
#         payload=jwt.decode(token,SECRET_KEY,algorithms=[ALGORITHM])
#         if payload.get("role") != "student":
#             raise HTTPException(status_code=status.HTTP_303_SEE_OTHER,headers={"location":"/student_login"})

#         return payload
#     except jwt.ExpiredSignatureError as ese:
#         logging.exception(f"JWT Token expiration: {str(ese)}")
#         raise HTTPException(status_code=status.HTTP_303_SEE_OTHER,headers={"location":"/refresh"})
#     except jwt.JWTError as je:
#         logging.exception(f"JWT Token : {str(je)}")
#         raise HTTPException(status_code=status.HTTP_303_SEE_OTHER,headers={"location":"/student_login"})




# def get_current_teacher(request:Request)->dict:
#     token=request.cookies.get("access_token")
#     if not token:
#         raise HTTPException(status_code=status.HTTP_303_SEE_OTHER,headers={"location":"/teacher_login"})
    
#     try:
#         payload=jwt.decode(token,SECRET_KEY,algorithms=[ALGORITHM])
#         if payload.get("role") != "teacher":
#             raise HTTPException(status_code=status.HTTP_303_SEE_OTHER,headers={"location":"/teacher_login"})
    
#         return payload
#     except jwt.ExpiredSignatureError as ese:
#         logging.exception(f"JWT Token expiration: {str(ese)}")
#         raise HTTPException(status_code=status.HTTP_303_SEE_OTHER,headers={"location":"/refresh"})
#     except jwt.JWTError as je:
#         logging.exception(f"JWT Token : {str(je)}")
#         raise HTTPException(status_code=status.HTTP_303_SEE_OTHER,headers={"location":"/teacher_login"})
    




# def get_current_admin(request:Request)->dict:
#     token=request.cookies.get("access_token")
#     if not token:
#         raise HTTPException(status_code=status.HTTP_303_SEE_OTHER,headers={"location":"/admin_login"})
    
#     try:
#         payload=jwt.decode(token,SECRET_KEY,algorithms=[ALGORITHM])
#         if payload.get("role") != "admin":
#             raise HTTPException(status_code=status.HTTP_303_SEE_OTHER,headers={"location":"/admin_login"})
    
#         return payload
#     except jwt.ExpiredSignatureError as ese:
#         logging.exception(f"JWT Token expiration: {str(ese)}")
#         raise HTTPException(status_code=status.HTTP_303_SEE_OTHER,headers={"location":"/refresh"})
#     except jwt.JWTError as je:
#         logging.exception(f"JWT Token : {str(je)}")
#         raise HTTPException(status_code=status.HTTP_303_SEE_OTHER,headers={"location":"/admin_login"})



# def get_chat_user(request:Request)->dict:
#     token=request.cookies.get("access_token")
#     if not token:
#         raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED,detail="login_required")
#     try:
#         payload=jwt.decode(token,SECRET_KEY,algorithms=[ALGORITHM])
#     except jwt.ExpiredSignatureError:
#         raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED,detail="expired")
#     except jwt.JWTError:
#         raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED,detail="invalid")
#     if payload.get("role") not in ("student","teacher","admin"):
#         raise HTTPException(status_code=status.HTTP_403_FORBIDDEN,detail="forbidden")
#     return payload







from urllib.parse import quote
from fastapi import HTTPException,Request,status
from core.logger import logging
from core.security import (ACCESS,ALGORITHM,TokenExpired,TokenInvalid,  decode_token)
from core.cookies import access_name


LOGIN_URL={
    "student":"/student_login",
    "teacher":"/teacher_login",
    "admin":"/admin_login",
}


def get_current_user(request:Request)->dict:
    try:
        user_id=request.session.get('user_id')
        if not user_id:
            raise HTTPException(status_code=status.HTTP_303_SEE_OTHER,headers={"location":"/main_view"})
        return {
            "user_id":user_id
            }
    except Exception as e:
        logging.exception(f"during gt crrnt user: {str(e)}")
        raise HTTPException(status_code=status.HTTP_303_SEE_OTHER,headers={"location":"/main_view"})


def _redirect(url:str)->HTTPException:
    return HTTPException(status_code=status.HTTP_303_SEE_OTHER,headers={"location":url})


def _refresh_url(request:Request,role:str)->str:
    if request.method=="GET":
        target=request.url.path + (f"?{request.url.query}" if request.url.query else "")
        return f"/refresh?role={role}&next={quote(target,safe='')}"
        # return f"/refresh?next={quote(target,safe='')}"
    return f"/refresh?role={role}"    
    # return "/refresh"


def _current(request:Request,role:str)->dict:
    token=request.cookies.get(access_name(role))
    if not token:
        raise _redirect(LOGIN_URL[role])
    try:
        return decode_token(token,ACCESS,expected_role=role)
    except TokenExpired as td:
        logging.error(f"tokn expired: {str(td)}")
        raise _redirect(_refresh_url(request,role))
    except TokenInvalid as e:
        logging.warning(f"Rejected access token for {role} page: {e}")
        raise _redirect(LOGIN_URL[role])


def get_current_student(request:Request)->dict:
    return _current(request,"student")


def get_current_teacher(request:Request)->dict:
    return _current(request,"teacher")


def get_current_admin(request:Request)->dict:
    return _current(request,"admin")



CHAT_ROLES=("student","teacher","admin")
def get_chat_user(request:Request)->dict:
    hint=request.query_params.get("role") or request.headers.get("x-role")
    roles=[hint] if hint in CHAT_ROLES else list(CHAT_ROLES)
    error="login_required"
    for role in roles:
        token=request.cookies.get(access_name(role))
        if not token:
            continue
        try:
            return decode_token(token,ACCESS,expected_role=role)
        except TokenExpired as te:
            logging.error(f"token expired : {str(te)}")
            error="expired"
        except TokenInvalid as ti:
            logging.warning(f"token invalid: {str(ti)}")
            error="invalid"
    raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED,detail=error)

# def get_chat_user(request:Request)->dict:
#     token=request.cookies.get("access_token")
#     if not token:
#         raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED,detail="login_required")
#     try:
#         return decode_token(token,ACCESS)         
#     except TokenExpired as te:
#         logging.error(f"token expired : {str(te)}")
#         raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED,detail="expired")
#     except TokenInvalid as ti:
#         logging.warning(f"token invalid: {str(ti)}")
#         raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED,detail="invalid")